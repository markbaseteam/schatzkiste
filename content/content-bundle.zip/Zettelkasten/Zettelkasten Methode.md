## Nie wieder Wissen verlernen

Luhmanns Zettelkasten – Bringen Sie Struktur in Ihr Wissensmanagement

https://zenkit.com/de/blog/zettelkasten-methode/

## Allgemeines zum Zettelkasten

### Struktur

> Achtung:
> Die folgende Struktur ist nur das Grundkonzept um eine Idee zu entwickeln, wie man seinen Zettelkasten am besten aufbauen kann. Wichtig ist lediglich, in einheitlicher Struktur und Vorgehensweise in seinem Zettelkasten zu arbeiten! Was man pro Note festhalten möchte und was nicht ist einem komplett selbst überlassen.

#### Literatur Notes

Note enthält Zitate, Markierungen, Gedanken zum Thema, Quellenangaben für später (z.B. ein Zitat mit Quellenangabe aus einem Buch, dass einem informativ oder wertvoll erschien)

#### Referenz Notes

Verbindungen zwischen vorhandenen Notes herstellen um Kontext für die Notes zu schaffen (z.B. in [[Obsidian]] Kategorisierung/Tags der vorhandenen Notes, Backlinks/Verlinkung zu vorhandenen Notes, Bilder/Videos, Sonstige Referenzierungen)

#### Permanente Notes

Vollendete alleinstehende Notes, die auf möglichst keine andere Note angewiesen ist. Quasi eine sauber ausgeführte Zusammenfassung aller Informationen zum Thema (z.B. eine vollständige Anleitung zur Einrichtung von Unity)

#### Flüchtige Notes

Kurze unsaubere Aufschriebe/Notes um Gedanken oder Informationen für später festzuhalten und nicht zu verlieren (z.B. Notizen aus Meetings)

#### Index Notes

Eine Art Inhaltsverzeichnis für den Zettelkasten um möglichst alle Unterthemen zu einem Thema auflisten zu können. (z.B. via Dataview in Obsidian als automatische query)

### Vorgehensweise

1. Neue Informationen, Gedanken und Gründe für die Gedanken in eigenen Worten aufschreiben

## Zettelkasten in [[Obsidian]]

- [ ] TODO-gn489 Text für "Eine Backlink Referenz pro Note reicht - am besten positioniert, wo sie in der Note am relevantesten ist"