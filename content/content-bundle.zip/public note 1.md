public text

public image remote
https://s8.gifyu.com/images/Animationc83524d2723e95c3.gif

<img src="https://s8.gifyu.com/images/Animationc83524d2723e95c3.gif" class="rounded-sm sm:rounded-lg">
